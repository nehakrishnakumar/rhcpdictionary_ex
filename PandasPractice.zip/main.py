# imports pandas and numpy, easier name for later use
import pandas as pd
import numpy as np

"""EXPERIMENTATION WITH DATA STRUCTURES OF PANDAS"""
#cops data from nearby rhcp.csv, converts it to a DataFrame, and prints it
data = pd.read_csv('rhcp.csv', encoding = 'utf-8');
print (data)

#creates dictionary of rhcp and ages and makes a series out of it
di = {"Chad Smith": "Will Ferrell", "Anthony Kiedis": "Jesus Christ", "Flea": "A Literal Rodent", "Josh": "That Guy No One Knows"}

p = pd.Series (di)
print (p)

# create series with scalars
q = pd.Series ("Anthony Kiedis' Long Hair", index = {0, 1, 2, 3})
print (q)

""""EXPERIMENTATION WITH DATA STRUCTURES OF NUMPY"""
# will be completed in due course