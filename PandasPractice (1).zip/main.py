# imports pandas and numpy, easier name for later use
import pandas as pd
from numpy import *

"""EXPERIMENTATION WITH DATA STRUCTURES OF PANDAS"""
#cops data from nearby rhcp.csv, converts it to a DataFrame, and prints it
data = pd.read_csv('rhcp.csv', encoding = 'utf-8');
print (data)

#creates dictionary of rhcp and ages and makes a series out of it
di = {"Chad Smith": "Will Ferrell", "Anthony Kiedis": "Jesus Christ", "Flea": "A Literal Rodent", "Josh": "That Guy No One Knows"}

p = pd.Series (di)
print (p)

# create series with scalars
q = pd.Series ("Anthony Kiedis' Long Hair", index = {0, 1, 2, 3})
print (q)

""""EXPERIMENTATION WITH DATA STRUCTURES OF NUMPY"""
# creates array and then ndarray out of it with array method
neha = {'Kiedis', 'Smith', 'Frusciante', 'Flea lol'}
n = array(neha)
print (n)

# find the length of an ndarray when given the two dimensions a and b
def getLen (a, b):
  return a * b
# write out the elements of the ndarray in a more aesthetically pleasing manner   
def ndToString(n, length):
  for i in range (0,length):
    print (n.item (i))
# creates 'empty' ndarray of size 4 x 3 and displays 'contents' to screen
numRows = 4
numCols = 3
no = empty ([numRows,numCols])  # question: How do you get the number of rows and number of columns in an ndarray without the need to make variables like these? Do I need to remake the whole class?
length = getLen(numRows,numCols)
print ('************CRISPY COOL RANDOM NUMBERS**********************')
ndToString (no, length)
# question 2: what is the difference between a general, regular multidimensional array and an ND array?

#horizontally stack two arrays (aka place them side by side) with ndarray
a = {True, False, True, False, True}
b = {False, False, False, False, False}
c = hstack (a, b)
print (c)



